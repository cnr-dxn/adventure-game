#ifndef ITEM_H
#define ITEM_H

//#include "Door.h"
//#include "Room.h"
#include <iostream>
#include <vector> 
#include <iomanip>
#include <math.h>
#include <string>
#include <algorithm>
#include <fstream>
#include <sstream>
using namespace std;

class Item
{
        public:
      	Item();
        Item(int, string, int);

        void setItemID(int);
	void setNameOfItem(string);
        void setIfItemIsNeeded(int);
	
	int getItemID();
        string getNameOfItem();
        int getIfItemIsNeeded();

        private:
        int itemID;
	string nameOfItem;
	int ifItemIsNeeded;
};

#endif

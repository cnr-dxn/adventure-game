#include "User.h"
#include <iostream>
#include <iomanip>
#include <math.h>
#include <vector> 
#include <string>
#include <algorithm>
#include <fstream>
#include <sstream>
using namespace std;

User::User()
{
	name = "";
	location = 0;
	itemID = 0;
}

User::User(string name_, int location_, int itemID_)
{
	name = name_;
	location = location_;
	itemID = itemID_;
	
}

void User::setName(string name_)
{
	name = name_;
}

void User::setLocation(int location_)
{
	location = location_;
}

void User::setItemID(int itemID_)
{
	itemID = itemID_;
}

string User::getName()
{
	return name;
}

int User::getLocation()
{
	return location;
}

int User::getItemID()
{
	return itemID;
}
